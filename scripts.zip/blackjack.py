import random
from time import *
from kandinsky import *
from ion import *






def draw_image(rle, x0, y0, w, pal, zoomx=1, zoomy=1, itransp=-1):
  i, x = 0, 0
  x0, y0 = int(x0), int(y0)
  nvals = len(pal)
  nbits = 0
  nvals -= 1
  while(nvals):
    nvals >>= 1
    nbits += 1
  maskval = (1 << nbits) - 1
  maskcnt = (0xFF >> nbits >> 1) << nbits
  while i<len(rle):
    v = rle[i]
    mv = v & maskval
    c = (v & maskcnt) >> nbits
    if (v & 0b10000000 or nbits == 8):
      i += 1
      c |= rle[i] << (7 - nbits + (nbits == 8))
    c = c + 1
    while c:
      cw = min(c, w - x)
      if mv != itransp:
        fill_rect(x0 + x*zoomx, y0, cw*zoomx, zoomy, pal[mv])
      c -= cw
      x = (x + cw) % w
      y0 += x == 0 and zoomy
    i += 1



palette2 = (
"k","w","#f0b080","#f0c098","#f0b488","#f0b078","#f0dcc0","#f0bc90","#f0ac78","#f8f8f0","#f0ac70","#f0a870","#e8a068","#e89c60","#e89860","#e89858","#e89458","#e89450","#e89050","#e88c48","#e88848","#e88840","#e88440","#a05820","#e88430","#e88030","#582c10","#e07c28","#e07828","#c86c20","#c86820","#d87428","#d87020","#d06c20","#c86818","#c86418","#c06018","#c06010","#b85c10","#b85810","#b05400","#d0a078","#b05000","#787878","#484448",
)


carte2  = (
b"\x80\23\xc1\21\xc0\0\1\xc0\0\x81\20\xc0\0\xc1\0\0\x81\20\xc0\0\1\0\xc1\1\x82\v\3\xc1\2\xc0\0\xc1\1\4\xc5\f\6\xc1\1\xc0\0\x81\1\a\xc8\r\t\x81\1\xc0\0\x81\1\xc8\16\x81\1\xc0\0\x81\1\xca\16\x81\1\xc0\0\x81\1\xcb\16\x81\1\xc0\0\x81\1\xcc\16\x81\1\xc0\0\x81\1\xcc\16\x81\1\xc0\0\x81\1\xcd\16\x81\1\xc0\0\x81\1\xcd\16\x81\1\xc0\0\x81\1\xce\16\x81\1\xc0\0\x81\1\xcf\16\x81\1\xc0\0\x81\1\xd0\16\x81\1\xc0\0\x81\1\xd1\16\x81\1\xc0\0\x81\1\xd2\5\xc0\1\xd2\6\x81\1\xc0\0\x81\1\x93\5\xc0\2\x93\6\x81\1\xc0\0\x81\1\x93\5\xc0\0\xd3\0\xc0\0\x93\6\x81\1\xc0\0\x81\1\x94\a\xc0\0\x94\6\x81\1\xc0\0\x81\1\x95\a\xc0\0\x95\6\x81\1\xc0\0\x81\1\xd6\6\xc0\0\27\x96\6\x81\1\xc0\0\x81\1\x98\6\x80\1\xd8\6\x81\1\xc0\0\x81\1\xd9\5\32\xc0\0\x99\a\x81\1\xc0\0\x81\1\xd9\5\xc0\0\xd9\a\x81\1\xc0\0\x81\1\x9b\5\xc0\0\x9b\b\x81\1\xc0\0\x81\1\x9c\5\xc0\2\35\xdc\5\x81\1\xc0\0\x81\1\x9c\5\xc0\2\36\xdc\5\x81\1\xc0\0\x81\1\xdf\16\x81\1\xc0\0\x81\1\xe0\16\x81\1\xc0\0\x81\1\xe0\16\x81\1\xc0\0\x81\1\xe1\16\x81\1\xc0\0\x81\1\xe1\16\x81\1\xc0\0\x81\1\xe2\16\x81\1\xc0\0\x81\1\xe3\16\x81\1\xc0\0\x81\1\xe3\16\x81\1\xc0\0\x81\1\xe4\16\x81\1\xc0\0\x81\1\xe5\16\x81\1\xc0\0\x81\1\xe6\16\x81\1\xc0\0\x81\1\xe7\16\x81\1\xc0\0\x81\1\xe7\16\x81\1\xc0\0\x81\1\xa8\16)\x81\1\xc0\0\xc1\1\xe8\r\xc1\1\xc0\0\xc1\2\xea\v\xc1\1+\1\xc0\0\x81\20\0\xc1\0\xc0\0\x81\20\0,\1\xc0\0\xc1\21\x80\23"
)



palette3 = (
"k","w","#d8e0d8","#f0f8f8","#88acd8","#90acd8","#88a8d8","#80a0d0","#d8e4f0","#a0b8d8","#809cd0","#789cd0","#7898d0","#7094d0","#7090d0","#6890c8","#688cc8","#6088c8","#6084c8","#5884c8","#5880c8","#507cc0","#5078c0","#4878c0","#4874c0","#182848","#4870b8","#4070b8","#406cb0","#4068b0","#4064a8","#3064a8","#3060a8","#3060a0","#305ca0","#305c98","#285898","#285490","#285090","#205088","#204c88","#204c80","#b8c4d8",(0,4,0),"#b0b4b0",
)


carte3  = (
b"\x80\23\xc1\21\xc0\0\2\0\xc1\20\xc0\0\1\0\xc1\20\xc0\1\x81\1\3\x84\f\5\xc1\1\xc0\0\x81\2\xc6\r\x81\1\xc0\0\xc1\1\x87\16\b\xc1\0\xc0\0\x81\1\t\xc7\16\xc1\0\xc0\0\x81\1\x8a\17\xc1\0\xc0\0\x81\1\x8b\17\xc1\0\xc0\0\x81\1\x8c\17\xc1\0\xc0\0\x81\1\x8d\17\xc1\0\xc0\0\x81\1\x8d\17\xc1\0\xc0\0\x81\1\x8e\17\xc1\0\xc0\0\x81\1\x8f\17\xc1\0\xc0\0\x81\1\x90\17\xc1\0\xc0\0\x81\1\x91\17\xc1\0\xc0\0\x81\1\x91\17\xc1\0\xc0\0\x81\1\x92\6\xc0\1\xd2\6\xc1\0\xc0\0\x81\1\xd3\5\xc0\2\x93\6\xc1\0\xc0\0\x81\1\xd4\5\xc0\0\xd4\0\xc0\0\x94\6\xc1\0\xc0\0\x81\1\xd4\a\xc0\0\x94\6\xc1\0\xc0\0\x81\1\xd5\a\xc0\0\x95\6\xc1\0\xc0\0\x81\1\xd6\6\x80\1\xd6\6\xc1\0\xc0\0\x81\1\xd7\6\xc0\1\x97\6\xc1\0\xc0\0\x81\1\xd8\a\xc0\0\x98\6\xc1\0\xc0\0\x81\1\xd8\a\31\0\x98\6\xc1\0\xc0\0\x81\1\xda\5\xc0\0\xda\0\xc0\0\x9a\6\xc1\0\xc0\0\x81\1\xdb\5\xc0\2\x9b\6\xc1\0\xc0\0\x81\1\x9c\6\xc0\1\xdc\6\xc1\0\xc0\0\x81\1\x9d\17\xc1\0\xc0\0\x81\1\x9d\17\xc1\0\xc0\0\x81\1\x9e\17\xc1\0\xc0\0\x81\1\x9f\17\xc1\0\xc0\0\x81\1\xa0\17\xc1\0\xc0\0\x81\1\xa1\17\xc1\0\xc0\0\x81\1\xa2\17\xc1\0\xc0\0\x81\1\xa3\17\xc1\0\xc0\0\x81\1\xa4\17\xc1\0\xc0\0\x81\1\xa4\17\xc1\0\xc0\0\x81\1\xa5\17\xc1\0\xc0\0\x81\1\xa5\17\xc1\0\xc0\0\xc1\1\xe6\16\xc1\0\xc0\0\xc1\1\xa7\16\x81\1\xc0\0\x81\2\xa8\r\xc1\1\xc0\0\x81\3\xa9\v*\xc1\0\0+\1\xc0\0\xc1\20,\1\xc0\0\x81\20+\0\1\xc0\0\xc1\21\xc0\0\xc1\21\0"
)


palette4 = (
"#e0e8e0","k","w","#c0c0c0","#f0f4f0","#c8c8c8","#c0c8c0","#d8e4d8","#d0d0d0","#c0c4c0","#e8ece8","#b8c0b8","#b8bcb8","#b8b8b8","#b0b4b0","#b0b0b0","#a8b0a8","#787878","#303830","#686868","#a8aca8","#909090","#888c88","#a0a8a0","#a0a0a0","#98a098","#808480","#989c98","#989898","#909490","#888888","#808080","#787c78","#d0d8d0","#707470","#707070","#686c68",
)


carte4 = (
b'\xc0\22\1\x82\22\1\2\3\x82\21\1\x82\22\x81\1\xc2\1\4\5\xc6\t\a\xc2\3\1\xc2\1\b\xc9\f\xc2\2\1\x82\1\b\xc9\r\x82\2\1\x82\1\x83\16\n\xc2\1\1\x82\1\xc3\16\xc2\1\1\x82\1\xcb\16\xc2\1\1\x82\1\xcc\16\xc2\1\1\x82\1\xcc\16\xc2\1\1\x82\1\xcc\16\xc2\1\1\x82\1\xcd\16\xc2\1\1\x82\1\xcd\16\xc2\1\1\x82\1\xce\16\xc2\1\1\x82\1\xce\16\xc2\1\1\x82\1\xce\16\xc2\1\1\x82\1\xcf\6\xc1\0\xcf\6\xc2\1\1\x82\1\xcf\6\xc1\0\xcf\6\xc2\1\1\x82\1\x90\6\xc1\0\21\xd0\6\xc2\1\1\x82\1\x90\6\xc1\0\x90\a\xc2\1\1\x82\1\xd0\5\22\1\23\x90\a\xc2\1\1\x82\1\xd4\5\xc1\0\xd4\0\1\25\xd4\5\xc2\1\1\x82\1\x94\5\x81\1\xd4\0\1\26\xd4\5\xc2\1\1\x82\1\x94\5\xc1\0\x94\1\1\26\xd4\5\xc2\1\1\x82\1\x97\5\x81\3\xd7\5\xc2\1\1\x82\1\x98\5\x81\3\xd8\5\xc2\1\1\x82\1\xd9\a\1\32\xd9\5\xc2\1\1\x82\1\xdb\a\25\x9b\6\xc2\1\1\x82\1\xdc\16\xc2\1\1\x82\1\xdd\16\xc2\1\1\x82\1\xdd\16\xc2\1\1\x82\1\xd5\16\xc2\1\1\x82\1\xd6\16\xc2\1\1\x82\1\xd6\16\xc2\1\1\x82\1\xde\16\xc2\1\1\x82\1\xda\16\xc2\1\1\x82\1\xdf\16\xc2\1\1\x82\1\xdf\16\xc2\1\1\x82\1\xe0\16\xc2\1\1\x82\1\xd1\16\xc2\1\1\x82\1\x91\16!\xc2\1\1\x82\1\26\xe2\r\x82\2\1\xc2\1\26\xe3\f\xc2\2\1\xc2\2\n"\xe4\t\20\xc2\1\1\x82\1\1\x82\22\1\x82\22\1\x82%'
)


palette5 = (
"k","w","#888888","#484448","#f8dc68","#f8dc60","#f8e488","#f8e070","#f8d860","#f8ecb0","#f8e078","#f8d858","#f8fcf0","#f8d050","#f8d048","#f8cc40","#f8cc30","#f8cc28","#f8c828","#f8c820","#e8bc20","#f8c818","#e8bc18","#f8c418","#483800","#f8c410","#e8bc10","#402c00","#e8b810","#f8c008","#e8b808","#201800","#f8c000","#f8bc00","#987400","#987800","#f0bc00","#d0a000","#f0b800","#e8b400","#705800","#e8b000","#e0b000","#d8ac00","#d8a800","#c89c00","#c89800","#c09400","#b89000","#b88c00","#b08c00","#b08800","#d0bc70","#b08400","#a88000",
)


carte5 = (
b'\x80\23\xc1\21\xc0\0\1\0\2\x81\20\xc0\0\1\3\xc1\20\xc0\0\xc1\0\0\x81\1\4\xc5\n\6\xc1\2\xc0\0\xc1\1\a\xc8\f\t\xc1\1\xc0\0\x81\1\n\xcb\r\f\x81\1\xc0\0\x81\1\xcb\16\x81\1\xc0\0\x81\1\xcd\16\x81\1\xc0\0\x81\1\xcd\16\x81\1\xc0\0\x81\1\xce\16\x81\1\xc0\0\x81\1\xce\16\x81\1\xc0\0\x81\1\xcf\16\x81\1\xc0\0\x81\1\xcf\16\x81\1\xc0\0\x81\1\xd0\16\x81\1\xc0\0\x81\1\xd1\16\x81\1\xc0\0\x81\1\xd2\16\x81\1\xc0\0\x81\1\xd3\16\x81\1\xc0\0\x81\1\xd3\5\24\xc0\2\x93\5\x81\1\xc0\0\x81\1\xd5\5\26\xc0\2\x95\5\x81\1\xc0\0\x81\1\xd7\5\26\0\30\x97\a\x81\1\xc0\0\x81\1\xd9\5\32\0\33\x99\a\x81\1\xc0\0\x81\1\xd9\5\34\x80\2\xd9\5\x81\1\xc0\0\x81\1\xdd\5\36\xc0\0\35\37\xc0\0\x9d\5\x81\1\xc0\0\x81\1\x9d\b\xc0\0\x9d\5\x81\1\xc0\0\x81\1\xa0\b\xc0\0\xa0\5\x81\1\xc0\0\x81\1\xe1\5"#\xa1\1\xc0\0\xa1\5\x81\1\xc0\0\x81\1\xe4\5%\xc0\0\xe4\0\xc0\0\xa4\5\x81\1\xc0\0\x81\1\xa6\6\x80\2\xe6\5\x81\1\xc0\0\x81\1\xe7\6(\xc0\0\xa7\6\x81\1\xc0\0\x81\1\xe9\16\x81\1\xc0\0\x81\1\xea\16\x81\1\xc0\0\x81\1\xea\16\x81\1\xc0\0\x81\1\xeb\16\x81\1\xc0\0\x81\1\xec\16\x81\1\xc0\0\x81\1\xe5\16\x81\1\xc0\0\x81\1\xe5\16\x81\1\xc0\0\x81\1\xed\16\x81\1\xc0\0\x81\1\xee\16\x81\1\xc0\0\x81\1\xef\16\x81\1\xc0\0\x81\1\xf0\16\x81\1\xc0\0\x81\1\xf1\16\x81\1\xc0\0\x81\1\xf2\16\x81\1\xc0\0\x81\1\xb3\x0e4\x81\1\xc0\0\xc1\1\xf5\r\xc1\1\xc0\0\xc1\2\xf6\v\x81\1\0\xc1\0\xc0\0\x81\20\0\xc1\0\xc0\0\xc1\21\xc0\0\xc1\21\x80\23'
)


palette6 = (
"k","w","#a8d088","#d0ecc0","#a0cc88","#a0cc80","#d8ecc8","#98c880","#98c878","#98c478","#90c470","#90c070","#90c068","#88c068","#88bc68","#88bc60","#80bc60","#689048","#80b858",(0,12,0),"#78b858","#78b450","#305020","#507830","#487028","#203c18","#78b448","#70b048","#285018","#588830","#305818","#588c30","#68ac48","#68ac40","#68a440","#68a040","#689c40","#609c40","#609840","#609430","#609030","#508430","#98b888","#508030","#507c28","#c8dcc0","#487828","#487428","#e8ece8",
)


carte6 = (
b"\xc0\22\x81\22\0\xc1\0\0\xc1\20\0\xc1\0\0\xc1\20\0\xc1\0\0\xc1\1\x82\v\3\xc1\2\0\x81\2\x84\r\x81\2\0\xc1\1\x85\16\xc1\1\0\xc1\1\xc5\16\x81\1\0\x81\1\6\xc7\16\x81\1\0\x81\1\x88\17\x81\1\0\x81\1\x89\17\x81\1\0\x81\1\x8a\17\x81\1\0\x81\1\x8a\17\x81\1\0\x81\1\x8b\17\x81\1\0\x81\1\x8c\17\x81\1\0\x81\1\x8d\17\x81\1\0\x81\1\x8e\17\x81\1\0\x81\1\x8f\17\x81\1\0\x81\1\xd0\6\xc0\0\21\xd0\6\x81\1\0\x81\1\xd2\6\xc0\0\x92\a\x81\1\0\x81\1\x92\6\xc0\0\23\x92\a\x81\1\0\x81\1\x94\6\xc0\0\xd4\a\x81\1\0\x81\1\xd5\5\26\0\27\30\x95\a\x81\1\0\x81\1\xd5\5\x80\2\31\x95\6\x81\1\0\x81\1\xda\5\xc0\0\xda\0\xc0\0\x9a\6\x81\1\0\x81\1\x9b\5\34\0\35\xdb\0\xc0\0\x9b\6\x81\1\0\x81\1\x9b\5\36\0\37\xdb\0\xc0\0\x9b\6\x81\1\0\x81\1\xdb\5\xc0\0\36\x80\1\x9b\6\x81\1\0\x81\1\xe0\5\x80\2\xe0\6\x81\1\0\x81\1\xa1\17\x81\1\0\x81\1\xa2\17\x81\1\0\x81\1\xa3\17\x81\1\0\x81\1\xa4\17\x81\1\0\x81\1\xa5\17\x81\1\0\x81\1\xa6\17\x81\1\0\x81\1\xa7\17\x81\1\0\x81\1\xa8\17\x81\1\0\x81\1\x9f\17\x81\1\0\x81\1\x9d\17\x81\1\0\x81\1\x9d\17\x81\1\0\x81\1\xa9\17\x81\1\0\x81\1*\xeb\16\x81\1\0\xc1\1\xec\16\x81\1\0\xc1\1\xac\16-\x81\1\0\x81\2\xee\r\xc1\1\0\xc1\2\xaf\f\x81\x010\xc1\0\0\xc1\20\0\xc1\0\0\x81\21\0\1\0\x81\22\x80\23"
)


palette7 = (
"w","k","r","#f80400","#f80c08",(72,0,0),(24,0,0),(40,0,0),"#e80000","#f83c40","#f87878","#787878",
)

carte7 = (
b"\xa0\16\21\xc0\4\1\x80\5\x82\3\3\xa0\1\xb2\3\x80\1\4\xb2\3\x80\1\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xb2\1\5Q\xa2\1\xf0\0\xb2\1\5Q\xa2\1\xf0\0\xb2\1\5\1\22\6\1\xb2\1\xf0\0\xb2\1\5\1\22\21\xb2\1\xf0\0\xf2\1\21\xb2\1\xf0\0\xf2\1\1\a\xb2\1\xf0\0\xe2\1\21\xc2\1\xf0\0\xe2\1\21\xc2\1\xf0\0\xe2\1\21\xc2\1\xf0\0\xd2\1\b\1\xd2\1\xf0\0\xd2\1\21\xd2\1\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xd2\3\xf0\0\xc2\3\x90\1\xb2\3\xa0\1\x92\3\xd0\1\t\xb2\2\n\x90\5\v\xc0\16"
)


palette8 = (
"k","w","#888888","#c0c0c0","#f0c8c8","#c80000","#d86868","#c00000","#e08080","#c80400","#c00400","#b80000","#b80400","#b00000","#a00000","#880000","#b00400","#900000",(88,0,0),"#a80000",(48,0,0),"#980000","#a80400",(96,0,0),"#680000","#a00400",(40,0,0),"#980400","#900400","#880400","#800000","#b87c78","#780000","#283028",
)



carte8 = (
b"\0\xc1\21\xc0\0\xc1\21\xc0\0\xc1\0\0\x81\20\xc0\0\xc1\21\xc0\0\1\2\xc1\20\xc0\0\xc1\0\3\x81\1\4\xc5\v\x81\2\xc0\0\x81\2\x85\r\6\x81\1\xc0\0\xc1\1\x85\16\x81\1\xc0\0\xc1\1\xc7\16\xc1\0\xc0\0\x81\1\b\xc7\16\xc1\0\xc0\0\x81\1\t\xc7\16\xc1\0\xc0\0\x81\1\n\xc7\16\xc1\0\xc0\0\x81\1\n\xc7\16\xc1\0\xc0\0\x81\1\n\xcb\16\xc1\0\xc0\0\x81\1\n\xcb\16\xc1\0\xc0\0\x81\1\n\xcb\16\xc1\0\xc0\0\x81\1\f\xcb\16\xc1\0\xc0\0\x81\1\f\xcb\16\xc1\0\xc0\0\x81\1\f\xcd\16\xc1\0\xc0\0\x81\1\f\x8d\6\xc0\0\16\xcd\6\xc1\0\xc0\0\x81\1\f\x8d\5\17\x80\2\x8d\6\xc1\0\xc0\0\x81\1\20\x8d\5\xc0\0\xcd\0\xc0\0\x8d\6\xc1\0\xc0\0\x81\1\20\x8d\5\xc0\0\xcd\0\21\0\22\xcd\5\xc1\0\xc0\0\x81\1\20\x8d\5\xc0\0\xcd\0\xc0\0\x8d\6\xc1\0\xc0\0\x81\1\20\xd3\5\x80\2\x93\6\xc1\0\xc0\0\x81\1\20\xd3\5\xc0\1\24\x93\6\xc1\0\xc0\0\x81\1\20\x93\5\xc0\0\xd3\0\xc0\0\25\xd3\5\xc1\0\xc0\0\x81\1\26\xd3\4\27\0\21\x93\1\xc0\0\xd3\5\xc1\0\xc0\0\x81\1\26\xce\4\30\xc0\0\x8e\1\xc0\0\xce\5\xc1\0\xc0\0\x81\1\26\x8e\5\xc0\2\x8e\6\xc1\0\xc0\0\x81\1\31\xce\5\xc0\1\32\x8e\6\xc1\0\xc0\0\x81\1\31\xd5\16\xc1\0\xc0\0\x81\1\31\xd5\16\xc1\0\xc0\0\x81\1\33\xd5\16\xc1\0\xc0\0\x81\1\33\xd1\16\xc1\0\xc0\0\x81\1\33\xd1\16\xc1\0\xc0\0\x81\1\33\xd1\16\xc1\0\xc0\0\x81\1\34\xcf\16\xc1\0\xc0\0\x81\1\34\xcf\16\xc1\0\xc0\0\x81\1\34\xcf\16\xc1\0\xc0\0\x81\1\34\xcf\16\xc1\0\xc0\0\x81\1\35\xde\16\xc1\0\xc0\0\x81\1\37\xde\16\xc1\0\xc0\0\xc1\1\xde\16\xc1\0\xc0\0\xc1\1\xa0\16\x81\1\xc0\0\x81\2\xe0\r\xc0\0\1\xc0\0\xc1\2\xa0\f\xc1\0!\0\1\xc0\0\x81\20\xc0\0\1\xc0\0\xc1\21\x80\23"
)

palette9 = (
"k","w","#e8ece8","#686868","#10c060","#00b850","#00c058","#00b848","#00b448","#00b048","#00ac48","#00a440","#00a040","#005c20","#009c40","#004c18","#009840","#007828","#008c30","#009430","#009030",(0,4,0),"#003010","#008830","#008430","#008428","#008028","#007c28","#007428","#007420","#f0f4f0","#007020","#e8f0e8","#409060","#006c20","#c0c0c0",
)


carte9  = (
b"\x80\23\xc1\21\xc0\0\1\0\2\x81\20\xc0\0\1\3\0\x81\20\xc0\0\xc1\21\xc0\0\x81\2\4\xc5\v\6\x81\2\xc0\0\xc1\1\xc7\r\xc1\1\xc0\0\x81\1\xc7\16\x81\1\xc0\0\x81\1\xc8\16\x81\1\xc0\0\x81\1\xc8\16\x81\1\xc0\0\x81\1\xc8\16\x81\1\xc0\0\x81\1\xc9\16\x81\1\xc0\0\x81\1\xc9\16\x81\1\xc0\0\x81\1\xc9\16\x81\1\xc0\0\x81\1\xc9\16\x81\1\xc0\0\x81\1\xc9\16\x81\1\xc0\0\x81\1\xca\16\x81\1\xc0\0\x81\1\xca\16\x81\1\xc0\0\x81\1\xca\16\x81\1\xc0\0\x81\1\xcb\16\x81\1\xc0\0\x81\1\xcb\6\xc0\1\xcb\5\x81\1\xc0\0\x81\1\x8b\6\xc0\2\x8b\5\x81\1\xc0\0\x81\1\x8c\6\xc0\0\xcc\0\xc0\0\x8c\5\x81\1\xc0\0\x81\1\x8c\6\0\r\xcc\0\xc0\0\x8c\5\x81\1\xc0\0\x81\1\x8c\6\xc0\0\xcc\0\xc0\0\x8c\5\x81\1\xc0\0\x81\1\x8e\6\xc0\2\x8e\5\x81\1\xc0\0\x81\1\xce\6\17\x80\1\20\x8e\5\x81\1\xc0\0\x81\1\xd0\a\xc0\0\xd0\5\x81\1\xc0\0\x81\1\x90\a\21\0\22\xd0\5\x81\1\xc0\0\x81\1\x93\a\xc0\0\x93\6\x81\1\xc0\0\x81\1\xd4\6\25\0\26\x94\6\x81\1\xc0\0\x81\1\xd4\6\xd2\0\xd4\6\x81\1\xc0\0\x81\1\xd2\16\x81\1\xc0\0\x81\1\xd2\16\x81\1\xc0\0\x81\1\xd7\16\x81\1\xc0\0\x81\1\xd8\16\x81\1\xc0\0\x81\1\xd9\16\x81\1\xc0\0\x81\1\xda\16\x81\1\xc0\0\x81\1\xda\16\x81\1\xc0\0\x81\1\xdb\16\x81\1\xc0\0\x81\1\xd1\16\x81\1\xc0\0\x81\1\xd1\16\x81\1\xc0\0\x81\1\xdc\16\x81\1\xc0\0\x81\1\xdd\16\x81\1\xc0\0\x81\1\36\xdf\r \x81\1\xc0\0\x81\2\xdf\f\x81\2\xc0\0\x81\3!\xe2\t!\x81\2#\1\xc0\0\x81\20\0\xc1\0\xc0\0\x81\20\0\xc1\0\x80\23"
)


palette10 = (
"k","w","#d8e0d8","#888888","#7020a0","#c0c0c0","#6820a0","#c0a8d8","#681ca0","#b898d0","#7030a0","#681c98","#702ca0","#702c98","#601c90","#682c98","#601890","#682890","#100020","#300450","#601888","#581888","#602890","#581488","#602888","#581480","#602088","#300c58","#501480","#501070","#602080","#501478","#582080","#501078","#581c78","#481070","#501c78","#480c68","#501c70","#c0b4c8","#400c68","#b8acc0","#603880","#400c60","#583078","#603c80","#603478","#b0a8c0","#401060","#400460",
)


carte10 = (
b'\xc0\22\xc1\21\0\1\2\1\3\xc1\17\0\1\0\3\x81\20\0\1\0\3\x81\1\x84\v\x81\3\0\x81\1\5\x84\r\x81\2\0\x81\1\x86\16\xc1\1\0\x81\1\x86\16\xc1\1\0\xc1\0\a\x88\16\t\x81\1\0\xc1\0\n\xc8\16\x81\1\0\xc1\0\n\xcb\16\x81\1\0\xc1\0\n\xcb\16\x81\1\0\xc1\0\f\xcb\16\x81\1\0\xc1\0\f\xcb\16\x81\1\0\xc1\0\f\xcb\16\x81\1\0\xc1\0\r\xcb\16\x81\1\0\xc1\0\r\xce\16\x81\1\0\xc1\0\17\xd0\16\x81\1\0\xc1\0\17\xd0\16\x81\1\0\xc1\0\17\xd0\4\xc0\0\xd0\1\x80\1\x90\5\x81\1\0\xc1\0\17\x90\4\x80\1\x90\1\x80\2\xd0\4\x81\1\0\xc1\0\21\x90\4\x80\1\xd0\0\22\0\23\xd0\0\xc0\0\x90\4\x81\1\0\xc1\0\21\xd0\4\xc0\0\xd0\0\xc0\0\x90\1\xc0\0\x90\4\x81\1\0\xc1\0\21\xd4\4\xc0\0\xd4\0\xc0\0\x94\1\xc0\0\x94\4\x81\1\0\xc1\0\21\xd5\4\xc0\0\xd5\0\xc0\0\x95\1\xc0\0\x95\4\x81\1\0\xc1\0\21\xd5\4\xc0\0\xd5\0\xc0\0\x95\1\xc0\0\x95\4\x81\1\0\xc1\0\26\xd7\4\xc0\0\xd7\0\xc0\0\x97\1\xc0\0\x97\4\x81\1\0\xc1\0\30\xd9\4\xc0\0\xd9\0\xc0\0\x99\1\xc0\0\x99\4\x81\1\0\xc1\0\30\xd9\4\xc0\0\xd9\0\xc0\0\x99\1\xc0\0\x99\4\x81\1\0\xc1\0\32\xd9\4\xc0\0\x99\1\x80\2\33\x99\4\x81\1\0\xc1\0\32\xdc\4\xc0\0\x9c\1\35\xc0\1\xdc\4\x81\1\0\xc1\0\36\xdf\16\x81\1\0\xc1\0 \xe1\16\x81\1\0\xc1\0 \xe1\16\x81\1\0\xc1\0 \xe1\16\x81\1\0\xc1\0"\xe3\16\x81\1\0\xc1\0"\xe3\16\x81\1\0\xc1\0$\xe3\16\x81\1\0\xc1\0$\xe5\16\x81\1\0\xc1\0&\xe5\16\x81\1\0\xc1\0&\xe5\16\x81\1\0\xc1\0\'\xa8\16)\x81\1\0\x81\1\xa8\16\xc1\1\0\x81\1*\xab\r,\xc1\1\0\xc1\1-\xab\f.\x81\2\0\xc1\2/0\xb1\t0/\xc1\0\5\xc0\0\xc1\0\0\x81\17\5\xc0\0\xc1\0\0\x81\17\5\xc0\0\xc1\0\0\x81$'
)


palette11 = (
"w","k","#c0c0c0","#00b8f8","#00b4f8","#68d0f8","#00b0f0","#c0f0f8","#70d0f8","#00acf0","#00ace0","#00a8e0","#00a0e0","#00a0d8","#009cd8","#0098d8","#0098d0","#0094d0","#0094c8","#0090c8","#008cc0","#0088c0","#0088b8","#0084b8","#0080b0","#007cb0","#0078a8","#0074a0","#70b0c8","#0070a0","#007098","#b8dce0","#006c98","#58a0b8","#006890","#888888",
)


carte11 = (
b"\x80\22\1\x80\22\1\0\2\0\1\x80\20\1\x80\1\1\x80\20\1\x80\1\1\xc0\0\3\xc4\v\xc0\2\1\x80\2\x84\r\5\xc0\1\1\xc0\1\x86\16\a\x80\1\1\xc0\1\xc6\16\x80\1\1\x80\1\b\xc6\16\x80\1\1\x80\1\x86\17\x80\1\1\x80\1\x86\17\x80\1\1\x80\1\x86\17\x80\1\1\x80\1\x89\17\x80\1\1\x80\1\x89\17\x80\1\1\x80\1\x89\17\x80\1\1\x80\1\x8a\17\x80\1\1\x80\1\x8b\17\x80\1\1\x80\1\x8b\17\x80\1\1\x80\1\x8c\17\x80\1\1\x80\1\x8c\6\xc1\0\x8c\1\xc1\0\x8c\5\x80\1\1\x80\1\x8d\5\xc1\1\xcd\0\x81\1\x8d\5\x80\1\1\x80\1\x8e\5\xc1\1\xce\0\x81\1\x8e\5\x80\1\1\x80\1\x8e\6\xc1\0\x8e\1\xc1\0\x8e\5\x80\1\1\x80\1\x8e\6\xc1\0\x8e\1\xc1\0\x8e\5\x80\1\1\x80\1\x8f\6\xc1\0\x8f\1\xc1\0\x8f\5\x80\1\1\x80\1\x90\6\xc1\0\x90\1\xc1\0\x90\5\x80\1\1\x80\1\x91\6\xc1\0\x91\1\xc1\0\x91\5\x80\1\1\x80\1\x92\6\xc1\0\x92\1\xc1\0\x92\5\x80\1\1\x80\1\x93\6\xc1\0\x93\1\xc1\0\x93\5\x80\1\1\x80\1\x93\6\xc1\0\x93\1\xc1\0\x93\5\x80\1\1\x80\1\x94\6\xc1\0\x94\1\xc1\0\x94\5\x80\1\1\x80\1\x95\17\x80\1\1\x80\1\x96\17\x80\1\1\x80\1\x97\17\x80\1\1\x80\1\x97\17\x80\1\1\x80\1\x98\17\x80\1\1\x80\1\x98\17\x80\1\1\x80\1\x99\17\x80\1\1\x80\1\x9a\17\x80\1\1\x80\1\x9a\17\x80\1\1\x80\1\x9b\17\x80\1\1\x80\1\34\xdb\16\x80\1\1\xc0\1\xdd\16\x80\1\1\xc0\1\x9e\16\37\x80\1\1\x80\2\xa0\r!\xc0\1\1\xc0\2\xa2\f\0\1\0#\xc0\0\1\xc0\17\2\0#\xc0\0\1\xc0\17\2\0#\xc0\0\1\x80\22\1\x80\22\1"
)

def creer_paquet():
    valeurs = [2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11]
    paquet = valeurs * 4
    for i in range(50):
        paquet.append(paquet.pop(random.randint(0,len(paquet)-1)))
    return paquet


def calculer_somme(cartes):
    somme = sum(cartes)
    #if somme > 21 and 11 in cartes:
    #    cartes.remove(11)
    #    cartes.append(1)
    #    somme = sum(cartes)
    return somme


def afficher_cartes(joueur, cartes, somme):
    draw_string(joueur,120-100*(joueur=="Croupier"),140*(joueur=="Croupier"),"b")
    for rang in range(len(cartes)):
        draw_image([carte2,carte3,carte4,carte5,carte6,carte7,carte8,carte9,carte10,carte11][cartes[rang]-2],150+40*rang,40+120*(joueur=="Croupier"),38-1*(cartes[rang]==10),[palette2,palette3,palette4,palette5,palette6,palette7,palette8,palette9,palette10,palette11][cartes[rang]-2],zoomx=1,zoomy=1,itransp=-1)
    #draw_string(f"{joueur}:\n cartes = {cartes},\n somme = {somme}")
    draw_string("somme : "+str(somme),120,20+120*(joueur=="Croupier"),"b")
    sleep(1)

def blackjack():
    paquet = creer_paquet()


    cartes_joueur = [paquet.pop(), paquet.pop()]
    cartes_croupier = [paquet.pop(), paquet.pop()]


    somme_joueur = calculer_somme(cartes_joueur)
    somme_croupier = calculer_somme(cartes_croupier)


    afficher_cartes("Joueur", cartes_joueur, somme_joueur)
    #draw_string("Croupier",40,140,"b")
    afficher_cartes("Croupier", cartes_croupier, somme_croupier)
    #draw_image([carte2,carte3,carte4,carte5,carte6,carte7,carte8,carte9,carte10,carte11][cartes_croupier[0]-2],150,160,38,[palette2,palette3,palette4,palette5,palette6,palette7,palette8,palette9,palette10,palette11][cartes_croupier[0]-2],zoomx=1,zoomy=1,itransp=-1)

    draw_string("pioche",20,0,"b")
    for i in range(50):
        for j in range(38):
            set_pixel(30+j,20+i,(255-int(2*(i+j)),128-int(2*(i+j)),0))
    #fill_rect(30,20,38,50,"y")

    while somme_joueur < 21:
        #choix = input("tirer une carte (tapez '1')\n ou rester (tapez '2')? ").lower()
        choix = 0
        draw_string("Appuyez sur gauche pour piocher\nou sur droite pour rester.",5,100,"r")
        while choix==0:

            if keydown(KEY_LEFT):
                choix = 1
            elif keydown(KEY_RIGHT):
                choix = 2
        #draw_string("Appuyez sur gauche pour piocher\nou sur droite pour rester.",5,50,"w")
        fill_rect(0,100,320,35,"w")
        draw_string(["on pioche !","on ne pioche pas !"][choix-1],100-30*choix,100,"g")
        sleep(1)
        draw_string(["on pioche !","on ne pioche pas !"][choix-1],100-30*choix,100,"w")
        if choix == 1:
            #N=len(cartes_joueur)
            carte_piochee=paquet.pop()
            draw_image([carte2,carte3,carte4,carte5,carte6,carte7,carte8,carte9,carte10,carte11][carte_piochee-2],30,20,38-1*(carte_piochee==10),[palette2,palette3,palette4,palette5,palette6,palette7,palette8,palette9,palette10,palette11][carte_piochee-2],zoomx=1,zoomy=1,itransp=-1)
            sleep(1)
            for i in range(50):
                for j in range(38):
                    set_pixel(30+j,20+i,(255-int(2*(i+j)),128-int(2*(i+j)),0))
            #fill_rect(30,20,38,50,"y")
            cartes_joueur.append(carte_piochee)


            somme_joueur =  calculer_somme(cartes_joueur)
            afficher_cartes("Joueur",cartes_joueur,somme_joueur)
        elif choix == 2:
            break



    if somme_joueur > 21:
        fill_rect(0,100,320,32,"w")
        draw_string("Vous avez dépassé 21,\n vous avez perdu!",20,100,"g")
        sleep(2)
        return


    #draw_string(f"Croupier: cartes = {cartes_croupier}, somme = {somme_croupier}",20,100,"g")
    while somme_croupier < 17:
        carte_piochee=paquet.pop()
        draw_image([carte2,carte3,carte4,carte5,carte6,carte7,carte8,carte9,carte10,carte11][carte_piochee-2],30,20,38-1*(carte_piochee==10),[palette2,palette3,palette4,palette5,palette6,palette7,palette8,palette9,palette10,palette11][carte_piochee-2],zoomx=1,zoomy=1,itransp=-1)
        sleep(1)
        for i in range(50):
            for j in range(38):
                set_pixel(30+j,20+i,(255-int(2*(i+j)),128-int(2*(i+j)),0))
        #fill_rect(30,20,38,50,"y")
        cartes_croupier.append(carte_piochee)
        somme_croupier = calculer_somme(cartes_croupier)
        afficher_cartes("Croupier", cartes_croupier, somme_croupier)
        #sleep(2)

    fill_rect(0,100,320,32,"w")
    if somme_croupier > 21:
        draw_string("Le croupier a dépassé 21,\n vous avez gagné!",20,100,"g")
    elif somme_joueur > somme_croupier:
        draw_string("Vous avez gagné!",20,100,"g")
    elif somme_joueur < somme_croupier:
        draw_string("Le croupier a gagné!",20,100,"g")
    else:
        draw_string("Match nul!",20,100,"g")
    sleep(2)

while 1:
    fill_rect(0,0,320,222,"w")
    blackjack()




