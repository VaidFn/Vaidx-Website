"""
Ce code doit être divisé dans trois scripts.

Pour installer directement vous pouvez aller sur ces trois liens :
    script echecs.py :          https://my.numworks.com/python/caucaucybu/echecs
    script parties_echecs.py :  https://my.numworks.com/python/caucaucybu/pieces_echecs
    script pieces_echecs.py :   https://my.numworks.com/python/caucaucybu/parties_echecs

Le sript echecs.py est remplaçable par le script echecs_simp.py disponible tout en bas ou sur le site de NumWorks :
    https://my.numworks.com/python/caucaucybu/echecs_simp

Aide :
    Pour les modes de jeu vous pouvez entre "continuer" pour continuer la partie enregistrée,
    "aleatoire" pour voir une partie aleatoire, "bot_blanc" et "bot_noir" pour jouer contre un bot ou "jeu" pour jouer une partie normale.
    On peut interrompre le jeu aleatoire et jouer soi-même en appuyant sur la touche [0]. Si la partie est interrompue,
    on peut la relancer en tapant restart() ou l’enregistrez pour la continuer plus tard en tapant donnees_partie()
    puis en copiant les lignes qui s’affichent et en les collant dans les lignes correspondantes dans le script parties_echecs.py.
    Vous pouvez modifiez les couleurs en haut du script pieces_echecs.py avec les variables blanc, noir et plt (plt c’est les deux couleurs du plateau)."""

#--------------------- script echecs.py ---------------------------#

from ion import keydown as keyp
from random import randint
aleat=0;ke=[0,0,0,0,0,0];rbb=rnb=tgb=tgn=tdb=tdn=1;rb=(0,4);rn=(7,4);pbb=pbhb=pbhn=pbn=0;grey=(165,166,165)
clf_av=[-5,-5,(0,0,0)];clf_ap=[-5,-6,"nopiece",(0,0,0)]
def keydown(k):
  if keyp(k) or ke[k]:return 1
def kerand():
  global ke
  if not keyp(48):ke=[randint(0,1) for i in range(6)]
  else:ke=[0,0,0,0,0,0]
def fin():
  try:
    while keydown(5):pass
  except KeyboardInterrupt:fin()
def sauver(tour):
  global svg
  svg_pbb=[];svg=[];svg_pbn=[];tr=tour
  for k in (0,-1):
    svg.append([])
    for i in range(8):
      for j in range(8):
        tst=chercher(i,j)
        if tst and tst[1]==k:svg[k].append((i,j,tst[0]))
  for i in range(9,7,-1):
    for j in range(7,0,-1):
      tst=chercher(i+0.4,j,1)
      if not tst[1]:svg_pbn.append((i+0.4,j,tst[0]))
      else:break
    if tst[1]:break
  for i in range(-2,0):
    for j in range(7,-1,-1):
      tst=chercher(i-0.4,j,1)
      if tst[1]==-1:svg_pbb.append((i-0.4,j,tst[0]))
      else:break
    if tst[1]!=-1:break
  svg.append(svg_pbn);svg.append(svg_pbb);svg.append([pbb,pbhb,pbhn,pbn,rb,rn,rnb,rbb,tdb,tdn,tgb,tgn,clf_av,clf_ap,tr,alea,aleat])
def navig(tour):
  global pbb,pbhb,pbhn,pbn,rb,rn,rnb,rbb,tdb,tdn,tgb,tgn,clf_av,clf_ap,ke
  sauver(tour);clf_ap_svg=clf_ap.copy();clf_av_svg=clf_av.copy();chess0=chess1=0;mat0=1;mat1=1
  pcsb=[svg[1][i][2] for i in range(len(svg[1]))];pcsn=[svg[0][i][2] for i in range(len(svg[0]))];del pcsb[pcsb.index("k")];del pcsn[pcsn.index("k")];ln=len(pcsn);lb=len(pcsb)
  if not echec(rn[0],rn[1],0):txt("ECHEC",265,3,(255,0,0),noir);chess0=1
  else:draw(265,3,50,18,noir)
  for i in svg[0]:
    depiece(i[0],i[1]);tst=chpsb(i[0],i[1],i[2],0);repiece0(i[0],i[1],i[2])
    if tst:mat0=0;break
  if mat0 and not tour:
    if chess0:txt(" MAT ",265,3,(255,0,0),noir)
    else:txt(" PAT ",265,3,(255,0,0),noir)
    return 1
  if not echec(rb[0],rb[1],-1):txt("ECHEC",5,3,(255,0,0),blanc);chess1=1
  else:draw(5,3,50,18,blanc)
  for i in svg[1]:
    depiece(i[0],i[1]);tst=chpsb(i[0],i[1],i[2],-1);repiece1(i[0],i[1],i[2])
    if tst:mat1=0;break
  if mat1 and tour==-1:
    if chess1:txt(" MAT ",5,3,(255,0,0),blanc)
    else:txt(" PAT ",5,3,(255,0,0),blanc)
    return 1
  if (lb==0 and ln==0) or (lb==0 and ln==1 and (pcsn[0]=="f" or pcsn[0]=="c")) or (ln==0 and lb==1 and (pcsb[0]=="f" or pcsb[0]=="c")):txt(" PAT ",5,3,(255,0,0));txt(" PAT ",265,3,(255,0,0),(0,0,0));return 1
  while 1:
    if not tour:c=chpiece(tour,7,-1)
    else:c=chpiece(tour,0,1)
    if aleat:kerand()
    else:ke=[0,0,0,0,0,0]
    while not keydown(4):
      if keydown(1):
        while keydown(1):
          if aleat:kerand()
        if not tour:
          w(c[0],c[1],c[2])
          c=chpiece(tour,c[0],-1,c[1],-1)
        else:
          r(c[0],c[1],c[2])
          c=chpiece(tour,c[0],1,c[1],-1)
      if keydown(2):
        while keydown(2):
          if aleat:kerand()
        if not tour:
          w(c[0],c[1],c[2])
          c=chpiece(tour,c[0],-1,c[1],1)
        else:
          r(c[0],c[1],c[2])
          c=chpiece(tour,c[0],1,c[1],1)
      if keydown(0):
        while keydown(0):
          if aleat:kerand()
        if not tour:
          w(c[0],c[1],c[2])
          c=chpiece(tour,c[0]-1,-1,c[1]+1,-1)
        else:
          r(c[0],c[1],c[2])
          c=chpiece(tour,c[0]-1,1,c[1]-1,1)
      if keydown(3):
        while keydown(3):
          if aleat:kerand()
        if not tour:
          w(c[0],c[1],c[2])
          c=chpiece(tour,c[0]+1,-1,c[1]-1,1)
        else:
          r(c[0],c[1],c[2])
          c=chpiece(tour,c[0]+1,1,c[1]+1,-1)
      if aleat:kerand()
    try:
      while keydown(4):
        if aleat:kerand()
      rang=0;go=1;depiece(c[0],c[1]);psb=chpsb(c[0],c[1],c[2],tour);psb.sort()
      try:
        psb[0]
        depiece(clf_av[0],clf_av[1],clf_av[2]);depiece(clf_ap[0],clf_ap[1],clf_ap[3]);clf=get(xn(c[0]),yn(c[1]));depiece(c[0],c[1],grey)
        if aleat:kerand()
        if not tour:repiece0(c[0],c[1],c[2]);repiece1(clf_ap[0],clf_ap[1],clf_ap[2])
        else:repiece1(c[0],c[1],c[2]);repiece0(clf_ap[0],clf_ap[1],clf_ap[2])
        for i in psb:repieceg(tour,i,c[2])
        while not keydown(4):
          if go:gris(psb[rang][0],psb[rang][1]);repieceg(tour,psb[rang],c[2]);go=0
          if keydown(2) and len(psb)!=1:
            while keydown(2):
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repieceg(tour,psb[rang],c[2])
            rang+=1;go=1
            if rang==len(psb):rang=0
          if keydown(1) and len(psb)!=1:
            while keydown(1):
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repieceg(tour,psb[rang],c[2])
            rang-=1;go=1
            if rang==-1:rang=len(psb)-1
          if keydown(0) and len(psb)!=1:
            while keydown(0):
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repieceg(tour,psb[rang],c[2]);arang=rang;rang-=1;go=1
            if rang==-1:rang=len(psb)-1
            while psb[arang][0]==psb[rang][0]:
              rang-=1
              if rang==-1:rang=len(psb)-1
              if rang==arang:
                rang-=1
                if rang==-1:rang=len(psb)-1
                break
          if keydown(3) and len(psb)!=1:
            while keydown(3):
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repieceg(tour,psb[rang],c[2]);arang=rang;rang+=1;go=1
            if rang==len(psb):rang=0
            while psb[arang][0]==psb[rang][0]:
              rang+=1
              if rang==len(psb):rang=0
              if rang==arang:
                rang+=1
                if rang==len(psb):rang=0
                break
          if aleat:kerand()
        while keydown(4):
          if aleat:kerand()
        for i in range(len(psb)):
          depiece(psb[i][0],psb[i][1])
          if len(psb[i])==3:
            if not tour:repiece1(psb[i][0],psb[i][1],psb[i][2])
            else:repiece0(psb[i][0],psb[i][1],psb[i][2])
      except IndexError:pass
      depiece(c[0],c[1])
      try:
        if len(psb[rang])>2:
          if psb[rang][2]!="roque":
            depiece(psb[rang][0],psb[rang][1])
            if not tour:
              repiece0(9.4-pbhn,7-pbn,psb[rang][2],blanc);pbn+=1
              if pbn==8:pbhn+=1;pbn=0
            else:
              repiece1(-2.4+pbhb,7-pbb,psb[rang][2],noir);pbb+=1
              if pbb==8:pbhb+=1;pbb=0
            if len(psb[rang])==5:depiece(psb[rang][3],psb[rang][4])
          else:
            pos=(psb[rang][0],psb[rang][1])
            if pos==(0,6):depiece(0,7);tourb(0,5)
            if pos==(0,2):depiece(0,0);tourb(0,3)
            if pos==(7,6):depiece(7,7);tourn(7,5)
            if pos==(7,2):depiece(7,0);tourn(7,3)
        pcs=["r","t","c","f"];rng=0;clf_ap=[psb[rang][0],psb[rang][1],c[2],get(xn(psb[rang][0]),yn(psb[rang][1]))]
        if not tour:
          repiece0(psb[rang][0],psb[rang][1],c[2])
          if c[2]=="p" and psb[rang][0]==0:
            depiece(psb[rang][0],psb[rang][1]);repiece0(psb[rang][0],psb[rang][1],pcs[rng]);gris(psb[rang][0],psb[rang][1])
            if aleat:kerand()
            while not keydown(4):
              if keydown(0) or keydown(1):
                while keydown(0) or keydown(1):
                  if aleat:kerand()
                rng+=1
                if rng==4:rng=0
                depiece(psb[rang][0],psb[rang][1]);repiece0(psb[rang][0],psb[rang][1],pcs[rng]);gris(psb[rang][0],psb[rang][1])
              if keydown(3) or keydown(2):
                while keydown(3) or keydown(2):
                  if aleat:kerand()
                rng+=1
                if rng==4:rng=0
                depiece(psb[rang][0],psb[rang][1]);repiece0(psb[rang][0],psb[rang][1],pcs[rng]);gris(psb[rang][0],psb[rang][1])
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repiece0(psb[rang][0],psb[rang][1],pcs[rng]);clf_ap[2]=pcs[rng]
        else:
          repiece1(psb[rang][0],psb[rang][1],c[2])
          if c[2]=="p" and psb[rang][0]==7:
            depiece(psb[rang][0],psb[rang][1]);gris(psb[rang][0],psb[rang][1]);repiece1(psb[rang][0],psb[rang][1],pcs[rng])
            if aleat:kerand()
            while not keydown(4):
              if keydown(0) or keydown(1):
                while keydown(0) or keydown(1):
                  if aleat:kerand()
                rng+=1
                if rng==4:rng=0
                depiece(psb[rang][0],psb[rang][1]);gris(psb[rang][0],psb[rang][1]);repiece1(psb[rang][0],psb[rang][1],pcs[rng])
              if keydown(3) or keydown(2):
                while keydown(3) or keydown(2):
                  if aleat:kerand()
                rng+=1
                if rng==4:rng=0
                depiece(psb[rang][0],psb[rang][1]);gris(psb[rang][0],psb[rang][1]);repiece1(psb[rang][0],psb[rang][1],pcs[rng])
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repiece1(psb[rang][0],psb[rang][1],pcs[rng]);clf_ap[2]=pcs[rng]
        if c[2]=="k":
          if not tour:rnb=0;rn=(psb[rang][0],psb[rang][1])
          else:rbb=0;rb=(psb[rang][0],psb[rang][1])
        if c[2]=="t":
          if c[1]==0:
            if not tour:tgn=0
            else:tgb=0
          if c[1]==7:
            if not tour:tdn=0
            else:tdb=0
        depiece(clf_ap[0],clf_ap[1],grey);clf_av=[c[0],c[1],clf]
        if not tour:repiece0(clf_ap[0],clf_ap[1],clf_ap[2])
        else:repiece1(clf_ap[0],clf_ap[1],clf_ap[2])
        while keydown(4):
          if aleat:kerand()
        break
      except IndexError:
        if not tour:repiece0(c[0],c[1],c[2])
        else:repiece1(c[0],c[1],c[2])
    except KeyboardInterrupt:
      fin()
      try:
        for i in range(len(psb)):
          depiece(psb[i][0],psb[i][1])
          if len(psb[i])==3:
            if not tour:repiece1(psb[i][0],psb[i][1],psb[i][2])
            else:repiece0(psb[i][0],psb[i][1],psb[i][2])
      except NameError:pass
      clf_av=clf_av_svg.copy();clf_ap=clf_ap_svg.copy();depiece(c[0],c[1],clf);depiece(clf_av[0],clf_av[1],grey);depiece(clf_ap[0],clf_ap[1],grey)
      if not tour:repiece0(c[0],c[1],c[2]);repiece1(clf_ap[0],clf_ap[1],clf_ap[2])
      else:repiece1(c[0],c[1],c[2]);repiece0(clf_ap[0],clf_ap[1],clf_ap[2])
def inter():print("La partie a ete interrompue.\nPour la reprendre, entrez \nrestart()\nPour l'enregistrer, entrez \ndonnees_partie()")
def donnees_partie():
  print("Copiez les lignes suivantes et\ncollez-les aux endroits\ncorrespondants dans le script\nparties_echecs.")
  for i in range(99999):pass
  print("","pieces_noires :\n"+str(svg[0]),"\npieces_blanches :\n"+str(svg[1]),"\npieces_mangees_noires :\n"+str(svg[2]),"\npieces_mangees_blanches :\n"+str(svg[3]),"\nautres_parametres :\n"+str(svg[4]))
def restart(partie=0):
  global pbb,pbhb,pbhn,pbn,rb,rn,rnb,rbb,tdb,tdn,tgb,tgn,clf_av,clf_ap,tour,aleat,alea
  if not partie:partie=svg
  charger("chargement partie enregistre");pbb=partie[4][0];pbhb=partie[4][1];pbhn=partie[4][2];pbn=partie[4][3];rb=partie[4][4];rn=partie[4][5];rnb=partie[4][6];rbb=partie[4][7]
  tdb=partie[4][8];tdn=partie[4][9];tgb=partie[4][10];tgn=partie[4][11];clf_av=partie[4][12];clf_ap=partie[4][13];tour=partie[4][14];alea=partie[4][15];aleat=partie[4][16]
  plateau();depiece(clf_av[0],clf_av[1],grey);depiece(clf_ap[0],clf_ap[1],grey)
  for j in range(2):
    for i in partie[j]:
      if  not j:repiece0(i[0],i[1],i[2])
      else:repiece1(i[0],i[1],i[2])
  for i in partie[3]:repiece1(i[0],i[1],i[2],(0,0,0))
  for i in partie[2]:repiece0(i[0],i[1],i[2],(255,255,255))
  if not tour:
    try:
      while 1:
        if navig(0):break
        if alea==-10:aleat=0
        elif alea==-1:aleat=1
        if navig(-1):break
        if alea==-10:aleat=1
        elif alea==-1:aleat=0
    except KeyboardInterrupt:inter()
  else:
    try:
      while 1:
        if navig(-1):break
        if alea==-10:aleat=1
        elif alea==-1:aleat=0
        if navig(0):break
        if alea==-10:aleat=0
        elif alea==-1:aleat=1
    except KeyboardInterrupt:inter()
def jeu(aleation):
  global aleat,alea
  if not aleation or aleation==-10:aleat=0
  else:aleat=1
  alea=aleation;plateau();reineb(0,3);reinen(7,3);roin(7,4);roib(0,4)
  for i in (0,7):tourb(0,i);tourn(7,i)
  for i in range(8):pionb(1,i);pionn(6,i)
  for i in (1,6):cavalierb(0,i);cavaliern(7,i)
  for i in (2,5):foub(0,i);foun(7,i)
  try:
    while 1:
      if navig(-1):break
      if aleation==-10:aleat=1
      elif aleation==-1:aleat=0
      if navig(0):break
      if aleation==-10:aleat=0
      elif aleation==-1:aleat=1
  except KeyboardInterrupt:inter()
def charger(t=0):
  if not t:t="chargement"
  if t==" ":print()
  else:print(t+"...")
  for i in range(16):print()
try:
  from parties_echecs import *
  bug_part=0
except ImportError:bug_part=1
try:
  from pieces_echecs import *
  bug_piec=0
except ImportError:bug_piec=1
if bug_piec and bug_part:print("Ce script d'echecs necessite\nabsolument pour fonctionner 2\nautres scripts pieces_echecs\net parties_echecs disponible\nsur mon compte numworks\nCaucaucybu ici :\nhttps://my.numworks.com/python\n/caucaucybu/pieces_echecs\nhttps://my.numworks.com/python\n/caucaucybu/parties_echecs")
elif bug_piec:print("Ce script d'echecs necessite\nabsolument pour fonctionner un\nautre script pieces_echecs.py\ndisponible sur mon compte\nnumworks Caucaucybu ici :\nhttps://my.numworks.com/python\n/caucaucybu/pieces_echecs")
elif bug_part:print("Ce script d'echecs necessite\nabsolument pour fonctionner un\nautre script parties_echecs.py\ndisponible sur mon compte\nnumworks Caucaucybu ici :\nhttps://my.numworks.com/python\n/caucaucybu/parties_echecs")
else:
  charger(" ")
  print("Bienvenue sur ce jeu d'echecs\ndeveloppe par Caucaucybu !")
  for i in range(9999):pass
  charger(" ")
  print("Vous pouvez entrer :\n-\"jeu\" pour commencer une\nnouvelle partie\n-\"tutoriel\" pour comprendre\ncomment jouer\n-\"continuer\" pour continuer la\npartie enregistree")
  rep=input("\n  ->")
  if rep=="continuer":
    try:restart([pieces_noires]+[pieces_blanches]+[pieces_mangees_noires]+[pieces_mangees_blanches]+[autres_parametres])
    except:print("Il n'y as pas de partie\nenregistre ou les donnees\nsont incompletes ou erronees.")
  elif rep=="tutoriel":
    charger();print("Deplacez la zone grisee vers\nla piece a jouer avec les\nfleches, puis appuyez sur OK.\nLes deplacements possibles\nvont vous etre propose.\nChoisissez le bon avec les\nfleches puis appuyez sur OK.\nS'il y a echec mat ou pat par\nimpossibilite de bouger ce\nsera indiques en haut a droite\nou a gauche de l'ecran.")
  elif rep=="jeu":
    charger();print("Cette version possede\ndifferents modes de jeu.\nVous pouvez entrer :\n-\"normal\" pour jouer un\nun contre un\n-\"aleatoire\" pour voir une\npartie jouee aleatoirement\n-\"bot_noir\" / \"bot_blanc\" pour\njouer contre un bot")
    rep=input("\n  ->")
    if rep=="aleatoire":
      charger("chargement partie aleatoire");print("Vous pouvez interrompre\nl'execution et jouer vous-meme\nen restant appuye sur la\ntouche 0.")
      for i in range(19999):pass
      charger(" ");jeu(1)
    elif rep=="normal":charger("chargement partie normale");jeu(0)
    elif rep=="bot_blanc":charger("en attente bot_blanc");jeu(-1)
    elif rep=="bot_noir":charger("en attente bot_noir");jeu(-10)
    else:charger("chargement nouvelle partie");jeu(0)
  elif rep=="aleatoire":
    charger("chargement partie aleatoire");print("Vous pouvez interrompre\nl'execution et jouer vous-meme\nen restant appuye sur la\ntouche 0.")
    for i in range(19999):pass
    charger(" ");jeu(1)
  elif rep=="normal":charger("chargement partie normale");jeu(0)
  elif rep=="bot_blanc":charger("en attente bot_blanc");jeu(-1)
  elif rep=="bot_noir":charger("en attente bot_noir");jeu(-10)
  else:charger("chargement nouvelle partie");jeu(0)



#--------------------- script parties_echecs.py ---------------------------#

try:from pieces_echecs import *
except ImportError:pass
def echec(x,y,tour,xy=0):
  for i in chpsb(x,y,"f",tour,0):
    if len(i)==3 and (i[2]=="f" or i[2]=="r"):
      if (i[0],i[1])!=xy:return 0
      else:break
  for i in chpsb(x,y,"t",tour,0):
    if len(i)==3 and (i[2]=="t" or i[2]=="r"):
      if (i[0],i[1])!=xy:return 0
      else:break
  for i in chpsb(x,y,"c",tour,0):
    if len(i)==3 and i[2]=="c":
      if (i[0],i[1])!=xy:return 0
      else:break
  for i in chpsb(x,y,"k",tour,0):
    if len(i)==3 and i[2]=="k":
      if (i[0],i[1])!=xy:return 0
      else:break
  for i in chpsb(x,y,"p",tour,0):
    if len(i)==3 and i[2]=="p":
      if (i[0],i[1])!=xy:return 0
      else:break
  return 1
def chpsb(x,y,typ,tour,ecs=1):
  try:from echecs import rb,rn,rbb,rnb,tgb,tgn,tdb,tdn
  except ImportError:from echecs_simp import rb,rn,rbb,rnb,tgb,tgn,tdb,tdn
  psb=[]
  if not tour:rt=(rn[0],rn[1])
  else:rt=(rb[0],rb[1])
  if typ=="p":
    if not tour:
      if not chercher(x-1,y):
        if ecs:pionn(x-1,y);ech=echec(rt[0],rt[1],tour,(x-1,y));depiece(x-1,y)
        else:ech=1
        if ech:psb.append((x-1,y))
        if x==6 and not chercher(x-2,y):
          if ecs:pionn(x-2,y);ech=echec(rt[0],rt[1],tour,(x-2,y));depiece(x-2,y)
          else:ech=1
          if ech:psb.append((x-2,y))
      for i in (-1,1):
        test=chercher(x-1,y+i)
        if inplt(y+i) and test and test[1]==-1:
          if ecs:ech=echec(rt[0],rt[1],tour,(x-1,y+i))
          else:ech=1
          if ech:psb.append((x-1,y+i,test[0]))
        if ecs and get(xn(x),yn(y+i))==grey and get(xn(x-2),yn(y+i))==grey and chercher(x,y+i)==("p",-1):
          depiece(x,y+i);pionn(x-1,y+i);ech=echec(rt[0],rt[1],tour);pionb(x,y+i);depiece(x-1,y+i)
          if ech:psb.append((x-1,y+i,"p",x,y+i))
    else:
      if not chercher(x+1,y):
        if ecs:pionb(x+1,y);ech=echec(rt[0],rt[1],tour,(x+1,y));depiece(x+1,y)
        else:ech=1
        if ech:psb.append((x+1,y))
        if x==1 and not chercher(x+2,y):
          if ecs:pionb(x+2,y);ech=echec(rt[0],rt[1],tour,(x+2,y));depiece(x+2,y)
          else:ech=1
          if ech:psb.append((x+2,y))
      for i in (-1,1):
        test=chercher(x+1,y+i)
        if inplt(y+i) and test and test[1]==0:
          if ecs:ech=echec(rt[0],rt[1],tour,(x+1,y+i))
          else:ech=1
          if ech:psb.append((x+1,y+i,test[0]))
        if ecs and get(xn(x),yn(y+i))==grey and get(xn(x+2),yn(y+i))==grey and chercher(x,y+i)==("p",0):
          depiece(x,y+i);pionn(x+1,y+i);ech=echec(rt[0],rt[1],tour);pionb(x,y+i);depiece(x+1,y+i)
          if ech:psb.append((x+1,y+i,"p",x,y+i))
  if typ=="t":
    x1=x+1;x2=x-1;y1=y+1;y2=y-1
    while x1<8:
      test=chercher(x1,y)
      if not test:
        if ecs:
          if not tour:tourn(x1,y)
          else:tourb(x1,y)
          ech=echec(rt[0],rt[1],tour,(x1,y));depiece(x1,y)
        else:ech=1
        if ech:psb.append((x1,y))
      elif test[1]!=tour:
        if ecs:ech=echec(rt[0],rt[1],tour,(x1,y))
        else:ech=1
        if ech:psb.append((x1,y,test[0]));break
      else:break
      x1+=1
    while x2>-1:
      test=chercher(x2,y)
      if not test:
        if ecs:
          if not tour:tourn(x2,y)
          else:tourb(x2,y)
          ech=echec(rt[0],rt[1],tour,(x2,y));depiece(x2,y)
        else:ech=1
        if ech:psb.append((x2,y))
      elif test[1]!=tour:
        if ecs:ech=echec(rt[0],rt[1],tour,(x2,y))
        else:ech=1
        if ech:psb.append((x2,y,test[0]));break
      else:break
      x2-=1
    while y1<8:
      test=chercher(x,y1)
      if not test:
        if ecs:
          if not tour:tourn(x,y1)
          else:tourb(x,y1)
          ech=echec(rt[0],rt[1],tour,(x,y1));depiece(x,y1)
        else:ech=1
        if ech:psb.append((x,y1))
      elif test[1]!=tour:
        if ecs:ech=echec(rt[0],rt[1],tour,(x,y1))
        else:ech=1
        if ech:psb.append((x,y1,test[0]));break
      else:break
      y1+=1
    while y2>-1:
      test=chercher(x,y2)
      if not test:
        if ecs:
          if not tour:tourn(x,y2)
          else:tourb(x,y2)
          ech=echec(rt[0],rt[1],tour,(x,y2));depiece(x,y2)
        else:ech=1
        if ech:psb.append((x,y2))
      elif test[1]!=tour:
        if ecs:ech=echec(rt[0],rt[1],tour,(x,y2))
        else:ech=1
        if ech:psb.append((x,y2,test[0]));break
      else:break
      y2-=1
  if typ=="c":
    for i in ((2,1),(2,-1),(-2,1),(-2,-1),(1,2),(-1,2),(1,-2),(-1,-2)):
      x0=x+i[0];y0=y+i[1];test=chercher(x0,y0)
      if inplt(x0) and inplt(y0):
        if not test:
          if ecs:
            if not tour:cavaliern(x0,y0)
            else:cavalierb(x0,y0)
            ech=echec(rt[0],rt[1],tour,(x0,y0));depiece(x0,y0)
          else:ech=1
          if ech:psb.append((x0,y0))
        elif test[1]!=tour:
          if ecs:ech=echec(rt[0],rt[1],tour,(x0,y0))
          else:ech=1
          if ech:psb.append((x0,y0,test[0]))
  if typ=="f":
    for i in range(1,8):
      if inplt(x+i) and inplt(y+i):
        test=chercher(x+i,y+i)
        if not test:
          if ecs:
            if not tour:foun(x+i,y+i)
            else:foub(x+i,y+i)
            ech=echec(rt[0],rt[1],tour,(x+i,y+i));depiece(x+i,y+i)
          else:ech=1
          if ech:psb.append((x+i,y+i))
        elif test[1]!=tour:
          if ecs:ech=echec(rt[0],rt[1],tour,(x+i,y+i))
          else:ech=1
          if ech:psb.append((x+i,y+i,test[0]));break
        else:break
      else:break
    for i in range(1,8):
      if inplt(x-i) and inplt(y-i):
        test=chercher(x-i,y-i)
        if not test:
          if ecs:
            if not tour:foun(x-i,y-i)
            else:foub(x-i,y-i)
            ech=echec(rt[0],rt[1],tour,(x-i,y-i));depiece(x-i,y-i)
          else:ech=1
          if ech:psb.append((x-i,y-i))
        elif test[1]!=tour:
          if ecs:ech=echec(rt[0],rt[1],tour,(x-i,y-i))
          else:ech=1
          if ech:psb.append((x-i,y-i,test[0]));break
        else:break
      else:break
    for i in range(1,8):
      if inplt(x+i) and inplt(y-i):
        test=chercher(x+i,y-i)
        if not test:
          if ecs:
            if not tour:foun(x+i,y-i)
            else:foub(x+i,y-i)
            ech=echec(rt[0],rt[1],tour,(x+i,y-i));depiece(x+i,y-i)
          else:ech=1
          if ech:psb.append((x+i,y-i))
        elif test[1]!=tour:
          if ecs:ech=echec(rt[0],rt[1],tour,(x+i,y-i))
          else:ech=1
          if ech:psb.append((x+i,y-i,test[0]));break
        else:break
      else:break
    for i in range(1,8):
      if inplt(x-i) and inplt(y+i):
        test=chercher(x-i,y+i)
        if not test:
          if ecs:
            if not tour:foun(x-i,y+i)
            else:foub(x-i,y+i)
            ech=echec(rt[0],rt[1],tour,(x-i,y+i));depiece(x-i,y+i)
          else:ech=1
          if ech:psb.append((x-i,y+i))
        elif test[1]!=tour:
          if ecs:ech=echec(rt[0],rt[1],tour,(x-i,y+i))
          else:ech=1
          if ech:psb.append((x-i,y+i,test[0]));break
        else:break
      else:break
  if typ=="r":psb=chpsb(x,y,"t",tour)+chpsb(x,y,"f",tour)
  if typ=="k":
    for i in ((1,0),(-1,0),(-1,1),(-1,-1),(1,1),(1,-1)):
      x0=x+i[0];y0=y+i[1]
      if inplt(x0) and inplt(y0):
        test=chercher(x0,y0)
        if ecs:ech=echec(x0,y0,tour)
        else:ech=1
        if not test:
          if ech:psb.append((x0,y0))
        elif test[1]!=tour and ech:psb.append((x0,y0,test[0]))
    y0=y+1
    if inplt(x) and inplt(y0):
      test=chercher(x,y0)
      if ecs:ech=echec(x,y0,tour)
      else:ech=1
      if not test:
        if ech:
          psb.append((x,y0))
          if not tour:
            if ecs and echec(x,y,tour) and rnb and tdn and chercher(7,7)==("t",0) and not chercher(7,5) and echec(x,y0+1,tour):psb.append((x,y0+1,"roque"))
          else:
            if ecs and echec(x,y,tour) and rbb and tdb and chercher(0,7)==("t",-1) and not chercher(0,5) and echec(x,y0+1,tour):psb.append((x,y0+1,"roque"))
      elif test[1]!=tour and ech:psb.append((x,y0,test[0]))
    y0=y-1
    if inplt(x) and inplt(y0):
      test=chercher(x,y0)
      if ecs:ech=echec(x,y0,tour)
      else:ech=1
      if not test:
        if ech:
          psb.append((x,y0))
          if not tour:
            if ecs and echec(x,y,tour) and rnb and tgn and chercher(7,0)==("t",0) and not chercher(7,2) and echec(x,y0-1,tour) and not chercher(7,1):psb.append((x,y0-1,"roque"))
          else:
            if ecs and echec(x,y,tour) and rbb and tgb and chercher(0,0)==("t",-1) and not chercher(0,2) and echec(x,y0-1,tour) and not chercher(0,1):psb.append((x,y0-1,"roque"))
      elif test[1]!=tour and ech:psb.append((x,y0,test[0]))
  return psb
pieces_noires=[(7,0,"k")]
pieces_blanches=[(0,0,"k"),(0,1,"f"),(0,2,"f")]
pieces_mangees_noires=[]
pieces_mangees_blanches=[]
autres_parametres=[0, 0, 0, 0, (0, 4), (7, 4), 1, 1, 1, 1, 1, 1, [-5, -5, (0, 0, 0)], [-5, -6, 'nopiece', (0, 0, 0)], -1, -10, 0]


#--------------------- script pieces_echecs.py ---------------------------#

from kandinsky import fill_rect as draw,draw_string as txt,get_pixel as get
grey=(165,166,165)
blanc=(255,255,255)
noir=(0,0,0)
plt=((222,97,24),(255,207,82))
def xn(xa):return 60+xa*25
def yn(ya):return 20+ya*25
def roin(x,y,c=noir):
  x=int(xn(x));y=int(yn(y))
  draw(x+21,y+3,3,19,c)
  draw(x+6,y+7,3,11,c)
  draw(x+2,y+11,19,3,c)
  for i in range(4):
    draw(x+11+3*i,y+2+i,3,3,c)
    draw(x+11+3*i,y+20-i,3,3,c)
  draw(x+12,y+5,2,15,c)
  draw(x+14,y+8,1,9,c)
  for i in (2,17):draw(x+11,y+i,2,6,c)
def roib(x,y,c=blanc):
  x=int(xn(x));y=int(yn(y))
  draw(x+1,y+3,3,19,c)
  draw(x+16,y+7,3,11,c)
  draw(x+4,y+11,19,3,c)
  for i in range(4):
    draw(x+11-3*i,y+2+i,3,3,c)
    draw(x+11-3*i,y+20-i,3,3,c)
  draw(x+11,y+5,2,15,c)
  draw(x+10,y+8,1,9,c)
  for i in (2,17):draw(x+12,y+i,2,6,c)
def reinen(x,y,c=noir):
  x=int(xn(x));y=int(yn(y))
  draw(x+21,y+3,3,19,c)
  for i in range(5):
    draw(x+8+3*i,y+1+i,3,3,c)
    draw(x+8+3*i,y+21-i,3,3,c)
  draw(x+7,y+11,14,3,c)
  draw(x+9,y+2,2,21,c)
  draw(x+11,y+8,1,9,c)
  for i in (2,17):draw(x+8,y+i,2,6,c)
def reineb(x,y,c=blanc):
  x=int(xn(x));y=int(yn(y))
  draw(x+1,y+3,3,19,c)
  for i in range(5):
    draw(x+14-3*i,y+1+i,3,3,c)
    draw(x+14-3*i,y+21-i,3,3,c)
  draw(x+4,y+11,14,3,c)
  draw(x+14,y+2,2,21,c)
  draw(x+13,y+8,1,9,c)
  for i in (2,17):draw(x+15,y+i,2,6,c)
def tourn(x,y,c=noir):
  x=int(xn(x));y=int(yn(y))
  draw(x+21,y+5,3,15,c)
  draw(x+10,y+8,11,9,c)
  draw(x+7,y+6,3,13,c)
  for i in (6,11,16):draw(x+4,y+i,3,3,c)
def tourb(x,y,c=blanc):
  x=int(xn(x));y=int(yn(y))
  draw(x+1,y+5,3,15,c)
  draw(x+4,y+8,11,9,c)
  draw(x+15,y+6,3,13,c)
  for i in (6,11,16):draw(x+18,y+i,3,3,c)
def cavaliern(x,y,c=noir):
  x=int(xn(x));y=int(yn(y))
  draw(x+21,y+6,3,14,c)
  draw(x+20,y+8,3,10,c)
  draw(x+16,y+9,4,8,c)
  draw(x+5,y+10,16,6,c)
  draw(x+9,y+16,5,4,c)
  draw(x+8,y+16,1,2,c)
def cavalierb(x,y,c=blanc):
  x=int(xn(x));y=int(yn(y))
  draw(x+1,y+6,3,14,c)
  draw(x+2,y+8,3,10,c)
  draw(x+5,y+9,4,8,c)
  draw(x+4,y+10,16,6,c)
  draw(x+11,y+6,5,4,c)
  draw(x+16,y+8,1,2,c)
def pionn(x,y,c=noir):
  x=int(xn(x));y=int(yn(y))
  draw(x+21,y+6,3,13,c)
  for i in range(3):
    draw(x+20-i*4,y+8+i,4,9-i*2,c)
    draw(x+13-i,y+10-i,1,5+i*2,c)
    draw(x+8-i,y+8+i,1,9-i*2,c)
  draw(x+9,y+8,2,9,c)
def pionb(x,y,c=blanc):
  x=int(xn(x));y=int(yn(y))
  draw(x+1,y+6,3,13,c)
  for i in range(3):
    draw(x+1+i*4,y+8+i,4,9-i*2,c)
    draw(x+11+i,y+10-i,1,5+i*2,c)
    draw(x+16+i,y+8+i,1,9-i*2,c)
  draw(x+14,y+8,2,9,c)
def foun(x,y,c=noir):
  x=int(xn(x));y=int(yn(y))
  draw(x+21,y+6,3,13,c)
  for i in range(3):
    draw(x+20-i*4,y+8+i,4,9-i*2,c)
    draw(x+14-i*2,y+10-i,2,5+i*2,c)
    draw(x+9-i*2,y+8+i,2,9-i*2,c)
  draw(x+3,y+11,2,3,c)
def foub(x,y,c=blanc):
  x=int(xn(x));y=int(yn(y))
  draw(x+1,y+6,3,13,c)
  for i in range(3):
    draw(x+1+i*4,y+8+i,4,9-i*2,c)
    draw(x+9+i*2,y+10-i,2,5+i*2,c)
    draw(x+14+i*2,y+8+i,2,9-i*2,c)
  draw(x+20,y+11,2,3,c)
def plateau():
  pl=0
  draw(59,1,202,16,plt[0])
  txt("Echecs by Caucaucybu",60,0,noir,plt[0])
  draw(59,19,202,202,noir)
  draw(60,20,200,200,blanc)
  draw(262,1,57,220,noir)
  draw(0,1,58,220,noir)
  draw(1,2,56,218,blanc)
  for i in range(60,255,25):
    if pl:pl=0
    else:pl=1
    for j in range(20,220,25):
      if pl:draw(i,j,25,25,plt[0]);pl=0
      else:draw(i,j,25,25,plt[1]);pl=1
def depiece(x,y,c=0):
  x=xn(x);y=yn(y)
  if not c:c=get(x,y)
  draw(x,y,25,25,c)
def chercher(x,y,rst=0):
  x=int(xn(x));y=int(yn(y));p=get(x+12,y+12);blanc=get(3,3);noir=get(315,3)
  if p in plt:return 0
  if rst:
    if p==blanc:pa=noir
    elif p==noir:pa=blanc
  else:pa=(p[0],p[1],p[2])
  if pa==noir:
    if get(x+4,y+6)==p:return "t",0
    if get(x+2,y+11)==p:return "k",0
    if get(x+8,y+2)==p:return "r",0
    if get(x+16,y+16)==p:return "c",0
    if get(x+3,y+11)==p:return "f",0
    return "p",0
  if pa==blanc:
    if get(x+20,y+6)==p:return "t",-1
    if get(x+22,y+11)==p:return "k",-1
    if get(x+15,y+2)==p:return "r",-1
    if get(x+8,y+16)==p:return "c",-1
    if get(x+20,y+11)==p:return "f",-1
    return "p",-1
def repiece0(x,y,tpe,c=noir):
  if tpe=="t":tourn(x,y,c)
  if tpe=="c":cavaliern(x,y,c)
  if tpe=="p":pionn(x,y,c)
  if tpe=="k":roin(x,y,c)
  if tpe=="r":reinen(x,y,c)
  if tpe=="f":foun(x,y,c)
def repiece1(x,y,tpe,c=blanc):
  if tpe=="t":tourb(x,y,c)
  if tpe=="c":cavalierb(x,y,c)
  if tpe=="p":pionb(x,y,c)
  if tpe=="k":roib(x,y,c)
  if tpe=="r":reineb(x,y,c)
  if tpe=="f":foub(x,y,c)
def chpiece(tour,i,it,j=-1,jt=1):
  tst=0
  while 1: 
    if tst and tst[1]==tour:break
    j+=jt
    if j==8:j=0;i-=it
    if j==-1:j=7;i+=it
    if i==-1:i=7
    if i==8:i=0
    tst=chercher(i,j)
  gris(i,j)
  if it==-1:repiece0(i,j,tst[0])
  if it==1:repiece1(i,j,tst[0])
  return i,j,tst[0]
def repieceg(tour,lst,tpi):
  x=lst[0];y=lst[1]
  if not tour:
    if len(lst)==3:repiece1(x,y,lst[2])
    repiece0(x,y,tpi,grey)
  else:
    if len(lst)==3:repiece0(x,y,lst[2])
    repiece1(x,y,tpi,grey)
def w(a,b,c):depiece(a,b);repiece0(a,b,c)
def r(a,b,c):depiece(a,b);repiece1(a,b,c)
def inplt(val):return -1<val<8
def gris(x,y):
  x=xn(x);y=yn(y);p=0
  for k in range(x,x+25):
    for l in range(y,y+25):
      if p:draw(k,l,1,1,(0,0,0));p=0
      else:p=1

#--------------------- script parties_echecs.py (peut remplacer echecs.py car il est moins lourd mais a moins d'aide) ---------------------------#

from ion import keydown as keyp
from random import randint
aleat=0;ke=[0,0,0,0,0,0];rbb=rnb=tgb=tgn=tdb=tdn=1;rb=(0,4);rn=(7,4);pbb=pbhb=pbhn=pbn=0;grey=(165,166,165)
clf_av=[-5,-5,(0,0,0)];clf_ap=[-5,-6,"nopiece",(0,0,0)]
def keydown(k):
  if keyp(k) or ke[k]:return 1
def kerand():
  global ke
  if not keyp(48):ke=[randint(0,1) for i in range(6)]
  else:ke=[0,0,0,0,0,0]
def fin():
  try:
    while keydown(5):pass
  except KeyboardInterrupt:fin()
def sauver(tour):
  global svg
  svg_pbb=[];svg=[];svg_pbn=[];tr=tour
  for k in (0,-1):
    svg.append([])
    for i in range(8):
      for j in range(8):
        tst=chercher(i,j)
        if tst and tst[1]==k:svg[k].append((i,j,tst[0]))
  for i in range(9,7,-1):
    for j in range(7,0,-1):
      tst=chercher(i+0.4,j,1)
      if not tst[1]:svg_pbn.append((i+0.4,j,tst[0]))
      else:break
    if tst[1]:break
  for i in range(-2,0):
    for j in range(7,-1,-1):
      tst=chercher(i-0.4,j,1)
      if tst[1]==-1:svg_pbb.append((i-0.4,j,tst[0]))
      else:break
    if tst[1]!=-1:break
  svg.append(svg_pbn);svg.append(svg_pbb);svg.append([pbb,pbhb,pbhn,pbn,rb,rn,rnb,rbb,tdb,tdn,tgb,tgn,clf_av,clf_ap,tr,alea,aleat])
def navig(tour):
  global pbb,pbhb,pbhn,pbn,rb,rn,rnb,rbb,tdb,tdn,tgb,tgn,clf_av,clf_ap,ke
  sauver(tour);clf_ap_svg=clf_ap.copy();clf_av_svg=clf_av.copy();chess0=chess1=0;mat0=1;mat1=1
  pcsb=[svg[1][i][2] for i in range(len(svg[1]))];pcsn=[svg[0][i][2] for i in range(len(svg[0]))];del pcsb[pcsb.index("k")];del pcsn[pcsn.index("k")];ln=len(pcsn);lb=len(pcsb)
  if not echec(rn[0],rn[1],0):txt("ECHEC",265,3,(255,0,0),noir);chess0=1
  else:draw(265,3,50,18,noir)
  for i in svg[0]:
    depiece(i[0],i[1]);tst=chpsb(i[0],i[1],i[2],0);repiece0(i[0],i[1],i[2])
    if tst:mat0=0;break
  if mat0 and not tour:
    if chess0:txt(" MAT ",265,3,(255,0,0),noir)
    else:txt(" PAT ",265,3,(255,0,0),noir)
    return 1
  if not echec(rb[0],rb[1],-1):txt("ECHEC",5,3,(255,0,0),blanc);chess1=1
  else:draw(5,3,50,18,blanc)
  for i in svg[1]:
    depiece(i[0],i[1]);tst=chpsb(i[0],i[1],i[2],-1);repiece1(i[0],i[1],i[2])
    if tst:mat1=0;break
  if mat1 and tour==-1:
    if chess1:txt(" MAT ",5,3,(255,0,0),blanc)
    else:txt(" PAT ",5,3,(255,0,0),blanc)
    return 1
  if (lb==0 and ln==0) or (lb==0 and ln==1 and (pcsn[0]=="f" or pcsn[0]=="c")) or (ln==0 and lb==1 and (pcsb[0]=="f" or pcsb[0]=="c")):txt(" PAT ",5,3,(255,0,0));txt(" PAT ",265,3,(255,0,0),(0,0,0));return 1
  while 1:
    if not tour:c=chpiece(tour,7,-1)
    else:c=chpiece(tour,0,1)
    if aleat:kerand()
    else:ke=[0,0,0,0,0,0]
    while not keydown(4):
      if keydown(1):
        while keydown(1):
          if aleat:kerand()
        if not tour:
          w(c[0],c[1],c[2])
          c=chpiece(tour,c[0],-1,c[1],-1)
        else:
          r(c[0],c[1],c[2])
          c=chpiece(tour,c[0],1,c[1],-1)
      if keydown(2):
        while keydown(2):
          if aleat:kerand()
        if not tour:
          w(c[0],c[1],c[2])
          c=chpiece(tour,c[0],-1,c[1],1)
        else:
          r(c[0],c[1],c[2])
          c=chpiece(tour,c[0],1,c[1],1)
      if keydown(0):
        while keydown(0):
          if aleat:kerand()
        if not tour:
          w(c[0],c[1],c[2])
          c=chpiece(tour,c[0]-1,-1,c[1]+1,-1)
        else:
          r(c[0],c[1],c[2])
          c=chpiece(tour,c[0]-1,1,c[1]-1,1)
      if keydown(3):
        while keydown(3):
          if aleat:kerand()
        if not tour:
          w(c[0],c[1],c[2])
          c=chpiece(tour,c[0]+1,-1,c[1]-1,1)
        else:
          r(c[0],c[1],c[2])
          c=chpiece(tour,c[0]+1,1,c[1]+1,-1)
      if aleat:kerand()
    try:
      while keydown(4):
        if aleat:kerand()
      rang=0;go=1;depiece(c[0],c[1]);psb=chpsb(c[0],c[1],c[2],tour);psb.sort()
      try:
        psb[0]
        depiece(clf_av[0],clf_av[1],clf_av[2]);depiece(clf_ap[0],clf_ap[1],clf_ap[3]);clf=get(xn(c[0]),yn(c[1]));depiece(c[0],c[1],grey)
        if aleat:kerand()
        if not tour:repiece0(c[0],c[1],c[2]);repiece1(clf_ap[0],clf_ap[1],clf_ap[2])
        else:repiece1(c[0],c[1],c[2]);repiece0(clf_ap[0],clf_ap[1],clf_ap[2])
        for i in psb:repieceg(tour,i,c[2])
        while not keydown(4):
          if go:gris(psb[rang][0],psb[rang][1]);repieceg(tour,psb[rang],c[2]);go=0
          if keydown(2) and len(psb)!=1:
            while keydown(2):
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repieceg(tour,psb[rang],c[2])
            rang+=1;go=1
            if rang==len(psb):rang=0
          if keydown(1) and len(psb)!=1:
            while keydown(1):
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repieceg(tour,psb[rang],c[2])
            rang-=1;go=1
            if rang==-1:rang=len(psb)-1
          if keydown(0) and len(psb)!=1:
            while keydown(0):
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repieceg(tour,psb[rang],c[2]);arang=rang;rang-=1;go=1
            if rang==-1:rang=len(psb)-1
            while psb[arang][0]==psb[rang][0]:
              rang-=1
              if rang==-1:rang=len(psb)-1
              if rang==arang:
                rang-=1
                if rang==-1:rang=len(psb)-1
                break
          if keydown(3) and len(psb)!=1:
            while keydown(3):
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repieceg(tour,psb[rang],c[2]);arang=rang;rang+=1;go=1
            if rang==len(psb):rang=0
            while psb[arang][0]==psb[rang][0]:
              rang+=1
              if rang==len(psb):rang=0
              if rang==arang:
                rang+=1
                if rang==len(psb):rang=0
                break
          if aleat:kerand()
        while keydown(4):
          if aleat:kerand()
        for i in range(len(psb)):
          depiece(psb[i][0],psb[i][1])
          if len(psb[i])==3:
            if not tour:repiece1(psb[i][0],psb[i][1],psb[i][2])
            else:repiece0(psb[i][0],psb[i][1],psb[i][2])
      except IndexError:pass
      depiece(c[0],c[1])
      try:
        if len(psb[rang])>2:
          if psb[rang][2]!="roque":
            depiece(psb[rang][0],psb[rang][1])
            if not tour:
              repiece0(9.4-pbhn,7-pbn,psb[rang][2],blanc);pbn+=1
              if pbn==8:pbhn+=1;pbn=0
            else:
              repiece1(-2.4+pbhb,7-pbb,psb[rang][2],noir);pbb+=1
              if pbb==8:pbhb+=1;pbb=0
            if len(psb[rang])==5:depiece(psb[rang][3],psb[rang][4])
          else:
            pos=(psb[rang][0],psb[rang][1])
            if pos==(0,6):depiece(0,7);tourb(0,5)
            if pos==(0,2):depiece(0,0);tourb(0,3)
            if pos==(7,6):depiece(7,7);tourn(7,5)
            if pos==(7,2):depiece(7,0);tourn(7,3)
        pcs=["r","t","c","f"];rng=0;clf_ap=[psb[rang][0],psb[rang][1],c[2],get(xn(psb[rang][0]),yn(psb[rang][1]))]
        if not tour:
          repiece0(psb[rang][0],psb[rang][1],c[2])
          if c[2]=="p" and psb[rang][0]==0:
            depiece(psb[rang][0],psb[rang][1]);repiece0(psb[rang][0],psb[rang][1],pcs[rng]);gris(psb[rang][0],psb[rang][1])
            if aleat:kerand()
            while not keydown(4):
              if keydown(0) or keydown(1):
                while keydown(0) or keydown(1):
                  if aleat:kerand()
                rng+=1
                if rng==4:rng=0
                depiece(psb[rang][0],psb[rang][1]);repiece0(psb[rang][0],psb[rang][1],pcs[rng]);gris(psb[rang][0],psb[rang][1])
              if keydown(3) or keydown(2):
                while keydown(3) or keydown(2):
                  if aleat:kerand()
                rng+=1
                if rng==4:rng=0
                depiece(psb[rang][0],psb[rang][1]);repiece0(psb[rang][0],psb[rang][1],pcs[rng]);gris(psb[rang][0],psb[rang][1])
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repiece0(psb[rang][0],psb[rang][1],pcs[rng]);clf_ap[2]=pcs[rng]
        else:
          repiece1(psb[rang][0],psb[rang][1],c[2])
          if c[2]=="p" and psb[rang][0]==7:
            depiece(psb[rang][0],psb[rang][1]);gris(psb[rang][0],psb[rang][1]);repiece1(psb[rang][0],psb[rang][1],pcs[rng])
            if aleat:kerand()
            while not keydown(4):
              if keydown(0) or keydown(1):
                while keydown(0) or keydown(1):
                  if aleat:kerand()
                rng+=1
                if rng==4:rng=0
                depiece(psb[rang][0],psb[rang][1]);gris(psb[rang][0],psb[rang][1]);repiece1(psb[rang][0],psb[rang][1],pcs[rng])
              if keydown(3) or keydown(2):
                while keydown(3) or keydown(2):
                  if aleat:kerand()
                rng+=1
                if rng==4:rng=0
                depiece(psb[rang][0],psb[rang][1]);gris(psb[rang][0],psb[rang][1]);repiece1(psb[rang][0],psb[rang][1],pcs[rng])
              if aleat:kerand()
            depiece(psb[rang][0],psb[rang][1]);repiece1(psb[rang][0],psb[rang][1],pcs[rng]);clf_ap[2]=pcs[rng]
        if c[2]=="k":
          if not tour:rnb=0;rn=(psb[rang][0],psb[rang][1])
          else:rbb=0;rb=(psb[rang][0],psb[rang][1])
        if c[2]=="t":
          if c[1]==0:
            if not tour:tgn=0
            else:tgb=0
          if c[1]==7:
            if not tour:tdn=0
            else:tdb=0
        depiece(clf_ap[0],clf_ap[1],grey);clf_av=[c[0],c[1],clf]
        if not tour:repiece0(clf_ap[0],clf_ap[1],clf_ap[2])
        else:repiece1(clf_ap[0],clf_ap[1],clf_ap[2])
        while keydown(4):
          if aleat:kerand()
        break
      except IndexError:
        if not tour:repiece0(c[0],c[1],c[2])
        else:repiece1(c[0],c[1],c[2])
    except KeyboardInterrupt:
      fin()
      try:
        for i in range(len(psb)):
          depiece(psb[i][0],psb[i][1])
          if len(psb[i])==3:
            if not tour:repiece1(psb[i][0],psb[i][1],psb[i][2])
            else:repiece0(psb[i][0],psb[i][1],psb[i][2])
      except NameError:pass
      clf_av=clf_av_svg.copy();clf_ap=clf_ap_svg.copy();depiece(c[0],c[1],clf);depiece(clf_av[0],clf_av[1],grey);depiece(clf_ap[0],clf_ap[1],grey)
      if not tour:repiece0(c[0],c[1],c[2]);repiece1(clf_ap[0],clf_ap[1],clf_ap[2])
      else:repiece1(c[0],c[1],c[2]);repiece0(clf_ap[0],clf_ap[1],clf_ap[2])
def inter():print("restart()\ndonnees_partie()")
def donnees_partie():print("Copiez les lignes suivantes","","pieces_noires :\n"+str(svg[0]),"\npieces_blanches :\n"+str(svg[1]),"\npieces_mangees_noires :\n"+str(svg[2]),"\npieces_mangees_blanches :\n"+str(svg[3]),"\nautres_parametres :\n"+str(svg[4]))
def restart(partie=0):
  global pbb,pbhb,pbhn,pbn,rb,rn,rnb,rbb,tdb,tdn,tgb,tgn,clf_av,clf_ap,tour,aleat,alea
  if not partie:partie=svg
  pbb=partie[4][0];pbhb=partie[4][1];pbhn=partie[4][2];pbn=partie[4][3];rb=partie[4][4];rn=partie[4][5];rnb=partie[4][6];rbb=partie[4][7]
  tdb=partie[4][8];tdn=partie[4][9];tgb=partie[4][10];tgn=partie[4][11];clf_av=partie[4][12];clf_ap=partie[4][13];tour=partie[4][14];alea=partie[4][15];aleat=partie[4][16]
  plateau();depiece(clf_av[0],clf_av[1],grey);depiece(clf_ap[0],clf_ap[1],grey)
  for j in range(2):
    for i in partie[j]:
      if  not j:repiece0(i[0],i[1],i[2])
      else:repiece1(i[0],i[1],i[2])
  for i in partie[3]:repiece1(i[0],i[1],i[2],(0,0,0))
  for i in partie[2]:repiece0(i[0],i[1],i[2],(255,255,255))
  if not tour:
    try:
      while 1:
        if navig(0):break
        if alea==-10:aleat=0
        elif alea==-1:aleat=1
        if navig(-1):break
        if alea==-10:aleat=1
        elif alea==-1:aleat=0
    except KeyboardInterrupt:inter()
  else:
    try:
      while 1:
        if navig(-1):break
        if alea==-10:aleat=1
        elif alea==-1:aleat=0
        if navig(0):break
        if alea==-10:aleat=0
        elif alea==-1:aleat=1
    except KeyboardInterrupt:inter()
def jeu(aleation):
  global aleat,alea
  if not aleation or aleation==-10:aleat=0
  else:aleat=1
  alea=aleation;plateau();reineb(0,3);reinen(7,3);roin(7,4);roib(0,4)
  for i in (0,7):tourb(0,i);tourn(7,i)
  for i in range(8):pionb(1,i);pionn(6,i)
  for i in (1,6):cavalierb(0,i);cavaliern(7,i)
  for i in (2,5):foub(0,i);foun(7,i)
  try:
    while 1:
      if navig(-1):break
      if aleation==-10:aleat=1
      elif aleation==-1:aleat=0
      if navig(0):break
      if aleation==-10:aleat=0
      elif aleation==-1:aleat=1
  except KeyboardInterrupt:inter()
try:
  from parties_echecs import *
  bug_part=0
except ImportError:bug_part=1
try:
  from pieces_echecs import *
  bug_piec=0
except ImportError:bug_piec=1
if bug_piec and bug_part:print("necessite pieces_echecs et parties_echecs")
elif bug_piec:print("necessite pieces_echecs.py")
elif bug_part:print("necessite parties_echecs.py")
else:
  rep=input("entrez mode de jeu : ")
  if rep=="continuer":
    try:restart([pieces_noires]+[pieces_blanches]+[pieces_mangees_noires]+[pieces_mangees_blanches]+[autres_parametres])
    except:print("Erreur")
  elif rep=="aleatoire":jeu(1)
  elif rep=="normal":jeu(0)
  elif rep=="bot_blanc":jeu(-1)
  elif rep=="bot_noir":jeu(-10)
  else:jeu(0)
